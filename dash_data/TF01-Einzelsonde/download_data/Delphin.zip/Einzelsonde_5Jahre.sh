#!/bin/bash

/usr/bin/MasterSimulator --verbosity-level=1 "/mnt/Daten/Forschung/Projekte/2022_MultiSource/Vergleich FEFLOW/Einzelsonde/Einzelsonde_5Jahre.msim"
exec bash
