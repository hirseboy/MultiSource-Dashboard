#!/bin/bash

/usr/bin/MasterSimulator --verbosity-level=1 "/mnt/Daten/Forschung/Projekte/2022_MultiSource/Vergleich FEFLOW/Sondenfeld/Feld_5x5_25_BoreholeProject_Konstant/Feld_5x5_25.msim"
exec bash
